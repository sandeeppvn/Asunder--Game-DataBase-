1. Click on the Link created called index.html.
2. After entering the database page click the Enter key.
3. Search the data base for any game by genre ,user , developer, publiser etc.
4. Provision for adding new user's is provided.
 Developed by a team of students:
 1. Satyam Bharadwaj
 2. Sahil Shah
 3. Siddharth Srinivasan
 4. Rishabh Soni
 